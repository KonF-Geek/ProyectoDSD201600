﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
namespace Entities.Reference
{
    public class EvaluacionViewModel {
        public Evaluacion evaluacion { get; set; }
        public List<SelectListItem> ubigeo { get; set; }
    }
    public class Evaluacion
    {
        [DisplayName("Nombres")]
        public string nombres { get; set; }

        [DisplayName("Apellido Paterno")]
        public string apePat { get; set; }
        
        [DisplayName("Apellido Materno")]
        public string apeMat { get; set; }

        [DisplayName("DNI")]
        public string dni { get; set; }

        [DisplayName("Fecha de Nacimiento")]
        public DateTime  fecNace { get; set; }

        [DisplayName("Celular")]
        public string celular { get; set; }

        [DisplayName("Correo")]
        public string correo { get; set; }

        [DisplayName("Direccion de Instalacion")]
        public string direcInstalacion { get; set; }

        [DisplayName("Distrito")]
        public ubigeo distrito { get; set; }
    }

    public class ubigeo {
        public int codigocodUbigeo { get; set; }
        public string descripcion { get; set; }
    }
}
