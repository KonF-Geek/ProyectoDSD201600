﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities.Reference;
namespace Claro2.WS
{
    public class WSProcesar
    {
        public string registrarSolicitudEvaluacion(Evaluacion e)
        {
            try
            {
                procesarClaro.ClaroWebService objregistrarSolEva = new procesarClaro.ClaroWebServiceClient();
                
                

                procesarClaro.registrarSolicitudEvaluacion  objrequest = new procesarClaro.registrarSolicitudEvaluacion();
                procesarClaro.registrarSolicitudEvaluacionResponse objresponse = new procesarClaro.registrarSolicitudEvaluacionResponse();
                
                objrequest.arg0.apemat = e.apeMat;
                objrequest.arg0.apePat = e.apePat;
                objrequest.arg0.nombres = e.nombres;
                objrequest.arg0.nroContacto = e.celular;
                objrequest.arg0.nroDocumentoIden = e.dni;
                objrequest.arg0.tipDocumento = 1;
                objrequest.arg0.codUbigeo = e.distrito.codigocodUbigeo;
                objrequest.arg0.direcFacturacion = e.direcInstalacion;
                objrequest.arg0.direcInstalacion = e.direcInstalacion;
                objrequest.arg0.estadoSec = 1;
                objrequest.arg0.fecNace = e.fecNace;
               // objresponse = objregistrarSolEva.registrarSolicitudEvaluacion(new procesarClaro.registrarSolicitudEvaluacion );
                
            }
            catch (Exception)
            {
                
                throw;
            }
            return "ok";
        }
    }
}
