﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Entities.Reference;
using Claro2.WS.procesarClaro;
using WebApplication2.procesarClaroWS;
namespace WebApplication2.Controllers
{
    public class PruebaController : Controller
    {
        //
        // GET: /Prueba/
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Prueba()
        {
            return View();
        }
        public ActionResult Prueba2()
        {
            
            var ubigeoList = new List<SelectListItem>();
            ubigeoList.Add(new SelectListItem {Value = "1",Text = "SMP"});
            ubigeoList.Add(new SelectListItem { Value = "2", Text = "Los Olivos" });

            EvaluacionViewModel evalViewModel = new EvaluacionViewModel();
            evalViewModel.evaluacion = new Evaluacion();
            evalViewModel.ubigeo = ubigeoList;
            return View(evalViewModel);
        }

        public ActionResult Solevaluacion(EvaluacionViewModel m)
        {
            //
            procesarClaroWS.ClaroWebServiceClient a = new procesarClaroWS.ClaroWebServiceClient();
            procesarClaroWS.solicitudEvaluacionDTO objrequest = new procesarClaroWS.solicitudEvaluacionDTO();
            Evaluacion e = m.evaluacion;

            objrequest.apemat = e.apeMat;
            objrequest.apePat = e.apePat;
            objrequest.nombres = e.nombres;
            objrequest.nroContacto = e.celular;
            objrequest.nroDocumentoIden = e.dni;
            objrequest.tipDocumento = 1;
            objrequest.codUbigeo = 1;// e.distrito.codigocodUbigeo;
            objrequest.direcFacturacion = e.direcInstalacion;
            objrequest.direcInstalacion = e.direcInstalacion;
            objrequest.estadoSec = 1;
            objrequest.fecNace = e.fecNace;
            objrequest.email = e.correo;

            try
            {
                a.registrarSolicitudEvaluacion(objrequest);
            }
            catch (System.Exception)
            {
                
                throw;
            }

            
            var ubigeoList = new List<SelectListItem>();
            ubigeoList.Add(new SelectListItem { Value = "1", Text = "SMP" });
            ubigeoList.Add(new SelectListItem { Value = "2", Text = "Los Olivos" });

            EvaluacionViewModel evalViewModel = m;
            evalViewModel.ubigeo = ubigeoList;
            return View("Prueba2", m);
        }
     
        
	}
}